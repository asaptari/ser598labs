<template>
  <div>
    <HelloWorld :name="name" />
    <Balance :amount="amount" :balance="balance" :fromCurrency="fromCurrency" @update-amount="updateAmount" />
    <Currency 
      :amount="amount" 
      :fromCurrency="fromCurrency" 
      :toCurrency="toCurrency"
      @update-amount="updateAmount"
      @update-fromCurrency="updateFromCurrency"
      @update-toCurrency="updateToCurrency"
    />
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue';
import Balance from './components/Balance.vue';
import Currency from './components/Currency.vue';

export default {
  components: {
    HelloWorld,
    Balance,
    Currency
  },
  data() {
    return {
      name: 'Mike',
      amount: 25,
      balance: 100,
      fromCurrency: 'USD',
      toCurrency: 'INR'
    };
  },
  methods: {
    updateAmount(newAmount) {
      this.amount = newAmount;
    },
    updateFromCurrency(newCurrency) {
      this.fromCurrency = newCurrency;
    },
    updateToCurrency(newCurrency) {
      this.toCurrency = newCurrency;
    }
  }
}
</script>
