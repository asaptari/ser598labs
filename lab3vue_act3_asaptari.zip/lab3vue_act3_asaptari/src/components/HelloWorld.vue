<template>
  <h1>Hello {{ name }}</h1>
</template>

<script>
export default {
  props: ['name']
}
</script>

<style scoped>
h1 {
  font-family: 'Times New Roman', Times, serif;
  color: green;
}
</style>
