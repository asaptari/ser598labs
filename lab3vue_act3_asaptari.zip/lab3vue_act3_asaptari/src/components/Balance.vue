<template>
  <div>
    <h3>Account Balance: {{ balance }} {{ fromCurrency }}, Amount: {{ amount }} {{ fromCurrency }}</h3>
    <div>
      <label>Change amount to:</label>
      <input type="range" v-model="localAmount" min="5" max="100" step="5" />
    </div>
    <button @click="addAmount">Add</button>
    <button @click="subtractAmount" :disabled="isSubtractDisabled">Subtract</button>
  </div>
</template>

<script>
export default {
  props: ['amount', 'balance', 'fromCurrency'],
  data() {
    return {
      localAmount: this.amount || 5 // default amount to 5
    };
  },
  computed: {
    isSubtractDisabled() {
      return this.localAmount > this.balance;
    }
  },
  watch: {
    amount(newVal) {
      this.localAmount = newVal;
    },
    localAmount(newVal) {
      this.$emit('update-amount', newVal);
    }
  },
  methods: {
    addAmount() {
      if (this.localAmount + 5 <= 100) {
        this.localAmount += 5;
      }
    },
    subtractAmount() {
      if (this.localAmount > 5) {
        this.localAmount -= 5;
      }
    }
  }
}
</script>

<style scoped>
h3 {
  font-size: 1.1em;
  font-weight: bold;
}
</style>
