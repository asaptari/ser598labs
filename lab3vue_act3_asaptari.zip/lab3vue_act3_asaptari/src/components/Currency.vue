<template>
 <div class="currency-converter">
    <h2>Currency Converter</h2>
    <label>Enter Amount: </label>
    <input v-model="localAmount" type="number" />

    <div>
      <label>Convert From:</label>
      <select :value="fromCurrency" @change="updateFromCurrency($event.target.value)">
        <option value="USD">US Dollar</option>
        <option value="BHD">Bahraini Dinar</option>
        <!-- Add other options as needed -->
      </select>

      <label>Convert To:</label>
      <select :value="toCurrency" @change="updateToCurrency($event.target.value)">
        <option value="INR">Indian Rupee</option>
        <option value="EUR">Euro</option>
        <!-- Add other options as needed -->
      </select>
    </div>

    <p>{{ localAmount }} {{ fromCurrency }} equals {{ convertedAmount }} {{ toCurrency }}</p>
  </div>
</template>

<script>
export default {
  props: ['amount', 'fromCurrency', 'toCurrency'],
  data() {
    return {
      localAmount: this.amount || 0,
      exchangeRates: {
        USD: { INR: 83.36, EUR: 0.94, USD: 1, BHD: 0.38 },
        BHD: { INR: 168.4, EUR: 2.35, USD: 2.65, BHD: 1 }
        // Add more exchange rates as needed
      }
    };
  },
  computed: {
    convertedAmount() {
      const rate = this.exchangeRates[this.fromCurrency][this.toCurrency] || 1;
      return (this.localAmount * rate).toFixed(2);
    }
  },
  watch: {
    amount(newVal) {
      this.localAmount = newVal;
    },
    localAmount(newVal) {
      this.$emit('update-amount', newVal);
    }
  },
  methods: {
    updateFromCurrency(newCurrency) {
      this.$emit('update-fromCurrency', newCurrency);
    },
    updateToCurrency(newCurrency) {
      this.$emit('update-toCurrency', newCurrency);
    }
  }
}
</script>

<style scoped>
.currency-converter {
  background-color: #f0f0f0; /* light grey background */
  padding: 10px;
  border-radius: 5px;
  font-family: Arial, sans-serif;
  
  margin-top: 20px;

}
h2 {
  font-size: 1.2em;
  font-weight: bold;
}
</style>
